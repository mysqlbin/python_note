from django.apps import AppConfig


class MetaManageConfig(AppConfig):
    name = 'meta_manage'
